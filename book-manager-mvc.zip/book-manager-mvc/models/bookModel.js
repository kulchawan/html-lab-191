const db = require("../config/db");

exports.findAll = async () => {
    const result = await db.query(
        "SELECT * FROM books ORDER BY id"
    );
    return result.rows;
};

exports.findById = async (id) => {
    const result = await db.query(
        "SELECT * FROM books WHERE id = $1", [id]
    );
    return result.rows[0] || null;
};

exports.create = async ({ title, author }) => {
  const result = await db.query(
    "INSERT INTO books (title, author) VALUES ($1, $2) RETURNING *",
    [title, author]
  );
  return result.rows[0];
};

exports.update = async (id, { title, author }) => {
  const result = await db.query(
    "UPDATE books SET title = $1, author = $2 WHERE id = $3 RETURNING *",
    [title, author, id]
  );
  return result.rows[0] || null;
};

exports.remove = async (id) => {
  const result = await db.query(
    "DELETE FROM books WHERE id = $1 RETURNING *",
    [id]
  );
  return result.rows[0] || null;
};