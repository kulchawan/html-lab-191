const bookModel = require("../models/bookModel");

exports.showBooksPage = async (req, res) => {
  try {
    const books = await bookModel.findAll();
    res.render("books/index", { books });
  } catch (err) {
    res.status(500).send("Failed to load books page");
  }
};

exports.showNewForm = (req, res) => {
  res.render("books/new");
};

exports.createBook = async (req, res) => {
  try {
    const { title, author } = req.body;

    if (!title || !author) {
      return res.status(400).send("Title and author are required");
    }

    await bookModel.create({ title, author });
    res.redirect("/books");
  } catch (err) {
    res.status(500).send("Failed to create book");
  }
};

exports.showEditForm = async (req, res) => {
  try {
    const book = await bookModel.findById(req.params.id);

    if (!book) {
      return res.status(404).send("Book not found");
    }

    res.render("books/edit", { book });
  } catch (err) {
    res.status(500).send("Failed to load edit page");
  }
};

exports.updateBook = async (req, res) => {
  try {
    const { title, author } = req.body;

    if (!title || !author) {
      return res.status(400).send("Title and author are required");
    }

    const updated = await bookModel.update(req.params.id, { title, author });

    if (!updated) {
      return res.status(404).send("Book not found");
    }

    res.redirect("/books");
  } catch (err) {
    res.status(500).send("Failed to update book");
  }
};

exports.deleteBook = async (req, res) => {
  try {
    const deleted = await bookModel.remove(req.params.id);

    if (!deleted) {
      return res.status(404).send("Book not found");
    }

    res.redirect("/books");
  } catch (err) {
    res.status(500).send("Failed to delete book");
  }
};